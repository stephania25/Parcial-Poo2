package Excepcion_Personalizada;

public class MiExcepcion extends Exception {
    private String Message;

    public MiExcepcion(String message) {
        Message = message;
    }

    public String exErrorPersonalizado(){
        return "ERROR";
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
