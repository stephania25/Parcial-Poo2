package Pun_Nueve;

import Pun_Nueve.Bienes_Raices;
import Pun_Nueve.Clientes;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) throws ExcepcionPersonalizada {

        Scanner scan = new Scanner(System.in);

        String opc;
        int opc_real;

        ArrayList<Clientes> Cliente = new ArrayList<>();

        Bienes_Raices b1 = new Bienes_Raices("apartamento", "3 PISO", "VENDIDO");
        Bienes_Raices b2 = new Bienes_Raices("casa", "1 PISO", "ARRENDADO");
        Bienes_Raices b3 = new Bienes_Raices("finca", "5 PISO ", "REPARACION");
        Bienes_Raices b4 = new Bienes_Raices("apartamento", "5 PISO", "VENDIDO");

        Clientes c1 = new Clientes(10, "SAMUEL HERRERA", "Propietario", b1);
        Clientes c2 = new Clientes(20, "LAURA SANTANA", "Inquilino", b2);
        Clientes c3 = new Clientes(30, "PABLO ESCOBAR", "Inquilino", b3);
        Clientes c4 = new Clientes(40, "JUAN RODRIGUEZ", "Propietario", b4);
        Cliente.add(c1);
        Cliente.add(c2);
        Cliente.add(c3);
        Cliente.add(c4);

        opc = scan.next();

        if(!opc.matches("[\\d]*")){
            throw new ExcepcionPersonalizada();
        }

        opc_real = Integer.parseInt(opc);

    }


}