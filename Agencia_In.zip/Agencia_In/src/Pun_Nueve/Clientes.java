package Pun_Nueve;

public class Clientes {
    private Integer codigo;
    private String nombre;
    private String tipo_Persona;


    public Clientes(Integer codigo, String nombre,String tipo_Persona, Bienes_Raices apartamento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo_Persona= tipo_Persona;

    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo_Persona() {
        return tipo_Persona;
    }

    public void setTipo_Persona(String tipo_Persona) {
        this.tipo_Persona = tipo_Persona;
    }

}
