package Pun_Nueve;

public class ExcepcionPersonalizada extends Exception {

    public ExcepcionPersonalizada(){

    }

    @Override
    public String getMessage(){

        String error = "";

        error = "El valor ingresado no es numerico";

        return error;

    }

}
