package Pun_Nueve;

public class Bienes_Raices {
    private String tipo;
    private String Localidad;
    private String Estado;

    public Bienes_Raices(String tipo, String localidad, String estado) {
        this.tipo= tipo;
        this.Localidad = localidad;
        this.Estado = estado;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getLocalidad() {
        return Localidad;
    }

    public void setLocalidad(String localidad) {
        Localidad = localidad;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        Estado = estado;
    }
}
