﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaz_1
{
    public partial class Form1 : Form
    {
        private String scan;
        private int conv;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_multiplos_Click(object sender, EventArgs e)
        {
            int j;
            conv = int.Parse(textBox1.Text);
            textBox1.Text = "";
            for (int i = 0; i <=9; i++)
            {
                j = conv * i;
                scan =  scan + j.ToString() + "  ";
                textBox1.Text = scan;
            }

        }

        private void btnborr_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            scan = " ";

        }

        private void btn_multiplon_Click(object sender, EventArgs e)
        {
            Double j = 0;
            conv = int.Parse(textBox1.Text);
            textBox1.Text = "";
            for (int i = 1; i <= conv ; i++)
            {
                
                j = Math.Pow(i, 2);

                scan = scan + j.ToString() + "  ";
                textBox1.Text = scan;
            }

        }

        private void btn_factorial_Click(object sender, EventArgs e)
        {
            int j = 1;
            int fac = 1;
            int cont = 0;
            j = int.Parse(textBox1.Text);
            textBox1.Text = "";
            for (int i = 1; i <= j ; i++)
            {
                cont = cont + 1;
                fac = fac * cont;
    
                scan = scan + cont.ToString() + "  ";
                textBox1.Text = scan;
            }
        }

        private void btn_fibonacci_Click(object sender, EventArgs e)
        {
            
            int n2 = 0;
            int n;
            int sum = 1;
            n = int.Parse(textBox1.Text);
            textBox1.Text = " ";
            for (int i = 1; i <= n; i++)
            {
                int n1 = 0;
                n1 = n2;
                n2 = sum;
                sum = n1 + n2;

                scan = scan + sum.ToString() + "  ";
                textBox1.Text = scan;
                
            }
        }  }
}
