﻿using System;

namespace Interfaz_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_multiplos = new System.Windows.Forms.Button();
            this.btn_multiplon = new System.Windows.Forms.Button();
            this.btn_factorial = new System.Windows.Forms.Button();
            this.btn_fibonacci = new System.Windows.Forms.Button();
            this.btnborr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 21);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 20);
            this.textBox1.TabIndex = 0;
            // 
            // btn_multiplos
            // 
            this.btn_multiplos.Location = new System.Drawing.Point(42, 57);
            this.btn_multiplos.Name = "btn_multiplos";
            this.btn_multiplos.Size = new System.Drawing.Size(88, 30);
            this.btn_multiplos.TabIndex = 1;
            this.btn_multiplos.Text = "MULTIPLOS";
            this.btn_multiplos.UseVisualStyleBackColor = true;
            this.btn_multiplos.Click += new System.EventHandler(this.btn_multiplos_Click);
            // 
            // btn_multiplon
            // 
            this.btn_multiplon.Location = new System.Drawing.Point(42, 93);
            this.btn_multiplon.Name = "btn_multiplon";
            this.btn_multiplon.Size = new System.Drawing.Size(88, 39);
            this.btn_multiplon.TabIndex = 2;
            this.btn_multiplon.Text = "MULTIPLO DE SERIE";
            this.btn_multiplon.UseVisualStyleBackColor = true;
            this.btn_multiplon.Click += new System.EventHandler(this.btn_multiplon_Click);
            // 
            // btn_factorial
            // 
            this.btn_factorial.Location = new System.Drawing.Point(42, 143);
            this.btn_factorial.Name = "btn_factorial";
            this.btn_factorial.Size = new System.Drawing.Size(88, 38);
            this.btn_factorial.TabIndex = 3;
            this.btn_factorial.Text = "FACTORIAL";
            this.btn_factorial.UseMnemonic = false;
            this.btn_factorial.UseVisualStyleBackColor = true;
            this.btn_factorial.Click += new System.EventHandler(this.btn_factorial_Click);
            // 
            // btn_fibonacci
            // 
            this.btn_fibonacci.Location = new System.Drawing.Point(42, 187);
            this.btn_fibonacci.Name = "btn_fibonacci";
            this.btn_fibonacci.Size = new System.Drawing.Size(88, 37);
            this.btn_fibonacci.TabIndex = 4;
            this.btn_fibonacci.Text = "FIBONACCI";
            this.btn_fibonacci.UseVisualStyleBackColor = true;
            this.btn_fibonacci.Click += new System.EventHandler(this.btn_fibonacci_Click);
            // 
            // btnborr
            // 
            this.btnborr.Location = new System.Drawing.Point(136, 120);
            this.btnborr.Name = "btnborr";
            this.btnborr.Size = new System.Drawing.Size(64, 37);
            this.btnborr.TabIndex = 5;
            this.btnborr.Text = "BORRAR";
            this.btnborr.UseVisualStyleBackColor = true;
            this.btnborr.Click += new System.EventHandler(this.btnborr_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(205, 236);
            this.Controls.Add(this.btnborr);
            this.Controls.Add(this.btn_fibonacci);
            this.Controls.Add(this.btn_factorial);
            this.Controls.Add(this.btn_multiplon);
            this.Controls.Add(this.btn_multiplos);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.RightToLeftLayout = true;
            this.Text = "Interfa_usuario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn_multiplos;
        private System.Windows.Forms.Button btn_multiplon;
        private System.Windows.Forms.Button btn_factorial;
        private System.Windows.Forms.Button btn_fibonacci;
        private System.Windows.Forms.Button btnborr;
    }
}

